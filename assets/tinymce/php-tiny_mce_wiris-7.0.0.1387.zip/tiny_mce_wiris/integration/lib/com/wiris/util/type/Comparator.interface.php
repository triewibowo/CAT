<?php

interface com_wiris_util_type_Comparator {
	function compare($a, $b);
}
